/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Poppins', 'sans-serif'],
        serif: ['"Source Serif 4"', 'serif'],
      },
      colors: {
        border: 'hsl(0 0% 100% / 0.1)',
      },
      borderRadius: {
        '--radius': '1rem',
      },
    },
  },
  plugins: [],
}
