import { useState } from 'react'
import { Sparkles, Download, Wand as Wand2, BookOpen, ArrowRight, Twitter, Linkedin, Instagram, Menu, Send, X, Shield, Code as Code2, Coins, Bot, FileText, Brain, Network, Boxes } from 'lucide-react'

const VIDEO_SRC =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260315_073750_51473149-4350-4920-ae24-c8214286f323.mp4'

const EXPERTISE = [
  { icon: Boxes, label: 'Блокчейн', desc: 'Смарт-контракты, dApps, интеграции on-chain.' },
  { icon: Bot, label: 'Автоматизация', desc: 'RPA-боты, обход защит, оркестрация процессов.' },
  { icon: Brain, label: 'AI / LLM', desc: 'On-premise модели, компьютерное зрение, пайплайны.' },
  { icon: Network, label: 'Интеграции', desc: 'Zoho Books, CRM, Unity SDK, платёжные шлюзы.' },
  { icon: FileText, label: 'Учёт и финансы', desc: 'Настройка планов счетов, UAE VAT, IFRS.' },
  { icon: Shield, label: 'Аудит и тестирование', desc: 'Экспресс-аудит, детальный аудит смарт-контрактов.' },
]

const PROJECTS = [
  {
    id: 'vfs-visa-bot',
    title: 'VFS Visa Bot',
    tag: 'Автоматизация',
    desc: 'Бот для записи на визу VFS Global с обходом Cloudflare Turnstile.',
    metric: 'Успешный обход Cloudflare',
  },
  {
    id: 'zoho-books',
    title: 'Zoho Books',
    tag: 'Интеграции',
    desc: 'Настройка плана счетов для управленческого и бухгалтерского учёта.',
    metric: 'Закрытие месяца за 2-3 дня вместо недели',
  },
  {
    id: 'blockchain-id',
    title: 'Achievement Engine',
    tag: 'Блокчейн',
    desc: 'Система идентификации, токенов и заслуг на Polygon.',
    metric: 'ID + Кошелёк + Ачивки на Polygon',
  },
  {
    id: 'ai-vision',
    title: 'AI Vision Demo',
    tag: 'AI / CV',
    desc: 'Видеоаналитика промышленной безопасности: детекция людей, фиксация нарушений.',
    metric: 'Покадровый анализ, таймкоды нарушений',
  },
  {
    id: 'content-factory',
    title: 'Web3 контент-завод',
    tag: 'Контент',
    desc: 'Атомизация и дистрибуция контента, мультиканальная публикация.',
    metric: 'Масштабируемость, no vendor lock-in',
  },
]

const STACK = [
  { group: 'Frontend', items: ['React 18', 'TypeScript', 'Vite', 'Tailwind CSS', 'Zustand', 'TanStack Query'] },
  { group: 'Backend', items: ['Node.js 20', 'NestJS', 'Python', 'FastAPI', 'REST / GraphQL API', 'Bull Queue'] },
  { group: 'Blockchain', items: ['Solidity', 'Hardhat', 'OpenZeppelin', 'Polygon PoS', 'Ethereum', 'MetaMask / WC', 'ERC-20 / 721 / 1155'] },
  { group: 'AI / CV', items: ['PyTorch', 'OpenCV', 'Llama 3.1 8B', 'Ollama LLM', 'AI Pipeline'] },
  { group: 'Data', items: ['PostgreSQL 16', 'Redis 7', 'Prisma ORM', 'IPFS / S3'] },
  { group: 'Infra', items: ['Docker + K8s', 'GitHub Actions', 'Prometheus', 'Sentry', 'AWS / GCP'] },
]

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [contactOpen, setContactOpen] = useState(false)

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden font-display text-white">
      {/* Video background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="fixed inset-0 h-full w-full object-cover"
        style={{ zIndex: 0 }}
      >
        <source src={VIDEO_SRC} type="video/mp4" />
      </video>
      <div className="fixed inset-0 bg-black/40" style={{ zIndex: 1 }} />

      {/* Content */}
      <div className="relative" style={{ zIndex: 10 }}>
        <Hero onMenu={() => setMenuOpen(true)} onContact={() => setContactOpen(true)} />
        <Expertise />
        <Projects />
        <Stack />
        <Footer onContact={() => setContactOpen(true)} />
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} />
      <ContactDrawer open={contactOpen} onClose={() => setContactOpen(false)} />
    </div>
  )
}

/* ---------- Hero (Bloom two-panel) ---------- */
function Hero({ onMenu, onContact }) {
  return (
    <section className="flex min-h-screen w-full flex-col lg:flex-row">
      {/* Left panel */}
      <div className="relative flex w-full flex-col lg:w-[52%]">
        <div className="liquid-glass-strong absolute inset-4 rounded-3xl lg:inset-6" />
        <div className="relative flex flex-1 flex-col p-8 lg:p-12">
          {/* Nav */}
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-full bg-white/10">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-semibold tracking-tighter text-white">unidev</span>
            </div>
            <button
              onClick={onMenu}
              className="liquid-glass flex items-center gap-2 rounded-full px-4 py-2 text-sm text-white/80 transition-transform hover:scale-105 active:scale-95"
            >
              <Menu className="h-4 w-4" />
              Меню
            </button>
          </nav>

          {/* Hero center */}
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div className="mb-8 grid h-20 w-20 place-items-center rounded-full bg-white/10">
              <Sparkles className="h-10 w-10 text-white" />
            </div>
            <h1 className="max-w-2xl text-5xl font-medium leading-[1.05] tracking-[-0.05em] text-white lg:text-7xl">
              Разработка <em className="font-serif font-normal text-white/80">Web3</em>,<br />
              блокчейн и <em className="font-serif font-normal text-white/80">корпоративные</em> решения
            </h1>
            <p className="mt-6 max-w-md text-sm text-white/60">
              Профессиональная разработка блокчейн-приложений на Polygon и Ethereum, интеграции с бизнес-системами, Unity SDK для игр и автоматизация процессов.
            </p>

            <a
              href="#projects"
              className="liquid-glass-strong mt-8 inline-flex items-center gap-3 rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-105 active:scale-95"
            >
              <span className="grid h-7 w-7 place-items-center rounded-full bg-white/15">
                <Download className="h-4 w-4" />
              </span>
              Смотреть проекты
            </a>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              {['Блокчейн', 'AI / LLM', 'Автоматизация', 'Интеграции'].map((p) => (
                <span
                  key={p}
                  className="liquid-glass rounded-full px-4 py-1.5 text-xs text-white/80"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* Bottom quote */}
          <div className="mt-10">
            <div className="text-xs uppercase tracking-[0.2em] text-white/50">Экспертиза</div>
            <p className="mt-3 text-lg font-medium text-white">
              <span className="font-display">Открыт к новым</span>{' '}
              <span className="font-serif italic text-white/80">проектам</span>
            </p>
            <div className="mt-3 flex items-center gap-3 text-xs uppercase tracking-widest text-white/50">
              <span className="h-px flex-1 bg-white/20" />
              Telegram · @LUXury_CEO
              <span className="h-px flex-1 bg-white/20" />
            </div>
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div className="relative hidden w-[48%] flex-col p-6 lg:flex">
        {/* Top bar */}
        <div className="flex items-center justify-end gap-3">
          <div className="liquid-glass flex items-center gap-3 rounded-full px-4 py-2">
            {[Twitter, Linkedin, Instagram].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-white transition-colors hover:text-white/80"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
            <ArrowRight className="h-4 w-4 text-white/60" />
          </div>
          <button
            onClick={onContact}
            className="liquid-glass flex items-center gap-2 rounded-full px-4 py-2 text-sm text-white transition-transform hover:scale-105 active:scale-95"
          >
            <Sparkles className="h-4 w-4" />
            Обсудить проект
          </button>
        </div>

        {/* Community card */}
        <div className="mt-6 w-56">
          <div className="liquid-glass rounded-2xl p-4">
            <div className="text-sm font-medium text-white">Войти в экосистему</div>
            <p className="mt-1 text-xs text-white/60">
              Web3, интеграции и корпоративные решения под ключ.
            </p>
          </div>
        </div>

        {/* Bottom feature section */}
        <div className="mt-auto">
          <div className="liquid-glass rounded-[2.5rem] p-5">
            <div className="grid grid-cols-2 gap-4">
              <FeatureCard icon={Wand2} title="Разработка" desc="Смарт-контракты и dApps под ключ." />
              <FeatureCard icon={BookOpen} title="Аудит" desc="Экспресс и детальный аудит кода." />
            </div>
            <div className="mt-4 flex items-center gap-3 rounded-3xl liquid-glass p-4">
              <div className="grid h-16 w-24 shrink-0 place-items-center rounded-2xl bg-white/10">
                <Coins className="h-7 w-7 text-white/80" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-white">Polygon Blockchain</div>
                <p className="mt-0.5 text-xs text-white/60">
                  ID + Кошелёк + Ачивки на Polygon.
                </p>
              </div>
              <button className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 text-white transition-transform hover:scale-105 active:scale-95">
                <X className="h-4 w-4 rotate-45" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ icon: Icon, title, desc }) {
  return (
    <div className="liquid-glass rounded-3xl p-4">
      <div className="grid h-8 w-8 place-items-center rounded-full bg-white/10">
        <Icon className="h-4 w-4 text-white" />
      </div>
      <div className="mt-3 text-sm font-medium text-white">{title}</div>
      <p className="mt-1 text-xs text-white/60">{desc}</p>
    </div>
  )
}

/* ---------- Expertise ---------- */
function Expertise() {
  return (
    <section id="expertise" className="px-6 py-24 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <SectionLabel>Экспертиза</SectionLabel>
        <h2 className="mt-4 max-w-2xl text-4xl font-medium tracking-tight text-white lg:text-5xl">
          Направления, которые{' '}
          <em className="font-serif font-normal text-white/80">закрываю под ключ</em>
        </h2>
        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {EXPERTISE.map((e) => (
            <div
              key={e.label}
              className="liquid-glass rounded-3xl p-6 transition-transform hover:scale-[1.02]"
            >
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/10">
                <e.icon className="h-5 w-5 text-white" />
              </div>
              <div className="mt-4 text-lg font-medium text-white">{e.label}</div>
              <p className="mt-1.5 text-sm text-white/60">{e.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------- Projects ---------- */
function Projects() {
  return (
    <section id="projects" className="px-6 py-24 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <SectionLabel>Проекты</SectionLabel>
            <h2 className="mt-4 max-w-2xl text-4xl font-medium tracking-tight text-white lg:text-5xl">
              Кейсы, которые{' '}
              <em className="font-serif font-normal text-white/80">решают бизнес-задачи</em>
            </h2>
          </div>
          <a
            href="#contact"
            className="liquid-glass-strong inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm text-white transition-transform hover:scale-105 active:scale-95"
          >
            Обсудить проект
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((p) => (
            <article
              key={p.id}
              className="liquid-glass group flex flex-col rounded-3xl p-6 transition-transform hover:scale-[1.02]"
            >
              <div className="flex items-center justify-between">
                <span className="liquid-glass rounded-full px-3 py-1 text-[11px] uppercase tracking-wider text-white/70">
                  {p.tag}
                </span>
                <ArrowRight className="h-4 w-4 text-white/40 transition-all group-hover:translate-x-0.5 group-hover:text-white" />
              </div>
              <h3 className="mt-5 text-xl font-medium text-white">{p.title}</h3>
              <p className="mt-2 flex-1 text-sm text-white/60">{p.desc}</p>
              <div className="mt-5 flex items-center gap-2 rounded-2xl bg-white/[0.03] px-3 py-2.5">
                <Sparkles className="h-3.5 w-3.5 shrink-0 text-white/60" />
                <span className="text-xs text-white/70">{p.metric}</span>
              </div>
            </article>
          ))}

          {/* CTA card */}
          <div className="liquid-glass-strong flex flex-col items-center justify-center rounded-3xl p-6 text-center">
            <div className="grid h-12 w-12 place-items-center rounded-full bg-white/10">
              <Send className="h-5 w-5 text-white" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-white">Нужен свой проект?</h3>
            <p className="mt-1.5 text-sm text-white/60">
              Расскажу, как решить вашу задачу на блокчейне или AI.
            </p>
            <a
              href="#contact"
              className="liquid-glass mt-5 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm text-white transition-transform hover:scale-105 active:scale-95"
            >
              Написать
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ---------- Tech Stack ---------- */
function Stack() {
  return (
    <section id="stack" className="px-6 py-24 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <SectionLabel>Стек технологий</SectionLabel>
        <h2 className="mt-4 max-w-2xl text-4xl font-medium tracking-tight text-white lg:text-5xl">
          Инструменты, на которых{' '}
          <em className="font-serif font-normal text-white/80">строю решения</em>
        </h2>
        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {STACK.map((s) => (
            <div key={s.group} className="liquid-glass rounded-3xl p-6">
              <div className="flex items-center gap-2">
                <Code2 className="h-4 w-4 text-white/60" />
                <span className="text-sm font-medium text-white">{s.group}</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {s.items.map((it) => (
                  <span
                    key={it}
                    className="liquid-glass rounded-full px-3 py-1 text-xs text-white/70"
                  >
                    {it}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------- Footer ---------- */
function Footer({ onContact }) {
  return (
    <footer id="contact" className="px-6 pb-12 pt-24 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="liquid-glass-strong rounded-[2.5rem] p-8 lg:p-12">
          <div className="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-center">
            <div>
              <SectionLabel>Контакты</SectionLabel>
              <h2 className="mt-4 text-3xl font-medium tracking-tight text-white lg:text-5xl">
                Готовы начать{' '}
                <em className="font-serif font-normal text-white/80">проект?</em>
              </h2>
              <p className="mt-3 max-w-md text-sm text-white/60">
                Открыт к новым проектам. Напишите на admin@aliterra.space или в Telegram.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <a
                href="https://t.me/LUXury_CEO"
                className="liquid-glass-strong inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-105 active:scale-95"
              >
                <Send className="h-4 w-4" />
                Telegram
              </a>
              <a
                href="mailto:admin@aliterra.space"
                className="liquid-glass inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-105 active:scale-95"
              >
                <ArrowRight className="h-4 w-4" />
                Написать на email
              </a>
            </div>
          </div>

          <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row">
            <span>© 2026 UniDev • Web3, Blockchain & Corporate Solutions</span>
            <div className="flex gap-4">
              {[Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="text-white/60 transition-colors hover:text-white/80">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

/* ---------- Drawers ---------- */
function MenuDrawer({ open, onClose }) {
  if (!open) return null
  const items = [
    { label: 'Экспертиза', href: '#expertise' },
    { label: 'Проекты', href: '#projects' },
    { label: 'Стек технологий', href: '#stack' },
    { label: 'Контакты', href: '#contact' },
  ]
  return (
    <div className="fixed inset-0" style={{ zIndex: 50 }}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="liquid-glass-strong absolute right-0 top-0 flex h-full w-80 max-w-[85vw] flex-col p-8">
        <div className="flex items-center justify-between">
          <span className="text-lg font-medium text-white">Меню</span>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
        <nav className="mt-8 flex flex-col gap-2">
          {items.map((it) => (
            <a
              key={it.href}
              href={it.href}
              onClick={onClose}
              className="liquid-glass rounded-2xl px-4 py-3 text-base text-white/80 transition-colors hover:text-white"
            >
              {it.label}
            </a>
          ))}
        </nav>
      </div>
    </div>
  )
}

function ContactDrawer({ open, onClose }) {
  if (!open) return null
  return (
    <div className="fixed inset-0" style={{ zIndex: 50 }}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="liquid-glass-strong absolute right-0 top-0 flex h-full w-96 max-w-[90vw] flex-col p-8">
        <div className="flex items-center justify-between">
          <span className="text-lg font-medium text-white">Обсудить проект</span>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
        <form
          className="mt-8 flex flex-1 flex-col gap-4"
          onSubmit={(e) => { e.preventDefault(); onClose() }}
        >
          <Field label="Имя" placeholder="Как к вам обращаться" />
          <Field label="Электронная почта*" placeholder="you@email.com" type="email" />
          <Field label="Telegram" placeholder="@username" />
          <div className="flex flex-1 flex-col">
            <label className="text-xs uppercase tracking-widest text-white/50">Сообщение</label>
            <textarea
              rows={5}
              placeholder="Опишите задачу"
              className="liquid-glass mt-2 flex-1 rounded-2xl p-4 text-sm text-white placeholder:text-white/40 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="liquid-glass-strong inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-105 active:scale-95"
          >
            <Send className="h-4 w-4" />
            Отправить
          </button>
        </form>
      </div>
    </div>
  )
}

function Field({ label, placeholder, type = 'text' }) {
  return (
    <label className="flex flex-col">
      <span className="text-xs uppercase tracking-widest text-white/50">{label}</span>
      <input
        type={type}
        placeholder={placeholder}
        className="liquid-glass mt-2 rounded-2xl px-4 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none"
      />
    </label>
  )
}

function SectionLabel({ children }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs uppercase tracking-[0.2em] text-white/60">
      <span className="h-1.5 w-1.5 rounded-full bg-white/60" />
      {children}
    </div>
  )
}
