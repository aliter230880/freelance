import { useState } from 'react';
import {
  Sparkles,
  Download,
  Wand2,
  BookOpen,
  ArrowRight,
  Twitter,
  Linkedin,
  Instagram,
  Menu,
  Plus,
  X,
  Cpu,
  Layers,
  Code2,
  Database,
  Cloud,
  GitBranch,
  ShieldCheck,
  Bot,
  Eye,
  Zap,
  Send,
  Mail,
} from 'lucide-react';

const VIDEO_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260315_073750_51473149-4350-4920-ae24-c8214286f323.mp4';

const FLOWER_IMG =
  'https://images.pexels.com/photos/14013669/pexels-photo-14013669.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

type FeaturedProject = {
  icon: typeof Wand2;
  title: string;
  description: string;
  tag: string;
};

const FEATURED_PROJECTS: FeaturedProject[] = [
  {
    icon: Wand2,
    title: 'AI Vision',
    description: 'Neural detection of industrial safety violations with real-time CCTV analytics.',
    tag: 'AI / CV',
  },
  {
    icon: BookOpen,
    title: 'Content Factory',
    description: 'Autonomous content generation pipeline with 24-node orchestration and multi-channel distribution.',
    tag: 'AI Pipeline',
  },
];

const SERVICE_PILLS = ['Blockchain & Web3', 'AI / Computer Vision', 'Automation'];

type Project = {
  icon: typeof Eye;
  title: string;
  subtitle: string;
  description: string;
  tags: string[];
  demoLabel?: string;
};

const ALL_PROJECTS: Project[] = [
  {
    icon: Eye,
    title: 'AI Vision Demo',
    subtitle: 'Видеоаналитика промышленной безопасности',
    description:
      'Нейросетевая детекция нарушений ТБ при взрывных работах: подсчёт людей в опасной зоне, фазовая фильтрация, акт видеофиксации, CCTV-демо.',
    tags: ['AI / CV', 'PyTorch', 'OpenCV', 'Python'],
    demoLabel: 'CCTV SURVEILLANCE',
  },
  {
    icon: Layers,
    title: 'Content Factory Dashboard',
    subtitle: 'Web3 контент-завод',
    description:
      'Полный pipeline от идеи до публикации — оркестрация в n8n, локальная LLM, 4 канала одновременной публикации, атомизация контента ×5.',
    tags: ['AI Pipeline', 'Llama 3.1', 'n8n', 'Self-hosted'],
    demoLabel: 'CONTENT FACTORY',
  },
  {
    icon: ShieldCheck,
    title: 'Blockchain Identity',
    subtitle: 'Система идентификации, токенов и заслуг',
    description:
      'ID + Кошелёк + Ачивки на Polygon. ERC-721 Soulbound NFT, ERC-20 Payment Token, ERC-1155 Achievements. MetaMask / WalletConnect.',
    tags: ['Blockchain & Web3', 'Solidity', 'Polygon', 'ERC-721'],
    demoLabel: 'BLOCKCHAIN ID',
  },
  {
    icon: Bot,
    title: 'VFS Visa Bot',
    subtitle: 'Автоматизация записи на визу',
    description:
      'Бот для автоматизации записи на визу через VFS Global. Обход защиты Cloudflare, работа с cookies, поддержка прокси и headless-режим.',
    tags: ['Automation', 'Selenium', 'Cloudflare Bypass', 'Python'],
    demoLabel: 'VFS BOT',
  },
  {
    icon: BookOpen,
    title: 'Zoho Books Setup',
    subtitle: 'Настройка плана счетов в Zoho Books',
    description:
      'Аудит и настройка планов счетов для управленческого и бухгалтерского учёта. Разбивка по ЦФУ B2B и Ecom, интеграция с внебанковскими платежами.',
    tags: ['Integration', 'Zoho Books', 'UAE VAT', 'IFRS'],
    demoLabel: 'ZOHO BOOKS',
  },
];

type ExpertiseArea = {
  icon: typeof Code2;
  title: string;
  items: string[];
};

const EXPERTISE_AREAS: ExpertiseArea[] = [
  {
    icon: Code2,
    title: 'Frontend & UX',
    items: ['React 18', 'TypeScript', 'Vite', 'Tailwind CSS', 'Unity SDK, C#', 'Mobile PWA'],
  },
  {
    icon: Cpu,
    title: 'Backend & Интеграции',
    items: ['NestJS', 'Node.js 20', 'Python, FastAPI', 'PostgreSQL 16', 'Redis 7', 'Prisma ORM'],
  },
  {
    icon: ShieldCheck,
    title: 'Blockchain & Web3',
    items: ['Solidity', 'Hardhat', 'OpenZeppelin', 'Polygon, Ethereum', 'MetaMask / WC', 'dApps, NFT, DeFi'],
  },
  {
    icon: Eye,
    title: 'AI / Computer Vision',
    items: ['PyTorch', 'OpenCV', 'Llama 3.1 8B', 'Ollama (local)', 'HSV-анализ', 'IoU-merge'],
  },
  {
    icon: Zap,
    title: 'Automation',
    items: ['Selenium', 'Playwright', 'Cloudflare Bypass', 'Cookie Management', 'Proxy Support', 'Headless mode'],
  },
  {
    icon: Database,
    title: 'Инфраструктура',
    items: ['Docker + K8s', 'GitHub Actions', 'Sentry', 'Prometheus', 'IPFS / S3', 'Cloudflare'],
  },
];

type TechCategory = {
  icon: typeof Cloud;
  label: string;
  techs: string[];
};

const TECH_STACK: TechCategory[] = [
  {
    icon: Code2,
    label: 'Frontend',
    techs: ['React 18', 'TypeScript', 'Vite', 'Tailwind CSS', 'TanStack Query'],
  },
  {
    icon: Cpu,
    label: 'Backend',
    techs: ['NestJS', 'Node.js 20', 'Python 3.8+', 'FastAPI', 'Prisma ORM', 'Bull Queue'],
  },
  {
    icon: ShieldCheck,
    label: 'Blockchain',
    techs: ['Solidity', 'Hardhat', 'OpenZeppelin', 'Polygon PoS', 'Ethereum', 'Infura RPC', 'ethers.js'],
  },
  {
    icon: Eye,
    label: 'AI / ML',
    techs: ['PyTorch', 'OpenCV', 'Llama 3.1 8B', 'Ollama LLM', 'Computer Vision'],
  },
  {
    icon: Cloud,
    label: 'Infrastructure',
    techs: ['Docker + K8s', 'GitHub Actions', 'Sentry', 'Prometheus', 'Cloudflare', 'IPFS / S3'],
  },
  {
    icon: Database,
    label: 'Data',
    techs: ['PostgreSQL 16', 'Redis 7', 'IPFS', 'S3 backup', 'Redis Cache'],
  },
];

function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none" className="shrink-0">
      <circle cx="40" cy="40" r="38" stroke="white" strokeOpacity="0.9" strokeWidth="1.5" />
      <path
        d="M40 14C31.16 14 24 21.16 24 30C24 38.84 31.16 46 40 46C40 37.16 47.16 30 56 30C47.16 30 40 22.84 40 14Z"
        fill="white"
        fillOpacity="0.9"
      />
      <path
        d="M40 66C48.84 66 56 58.84 56 50C56 41.16 48.84 34 40 34C40 42.84 32.84 50 24 50C32.84 50 40 57.16 40 66Z"
        fill="white"
        fillOpacity="0.6"
      />
      <circle cx="40" cy="40" r="4" fill="white" />
    </svg>
  );
}

function IconContainer({ children, size = 'w-8 h-8' }: { children: React.ReactNode; size?: string }) {
  return (
    <span className={`${size} rounded-full bg-white/10 flex items-center justify-center`}>
      {children}
    </span>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="h-px w-8 bg-white/30" />
      <span className="text-xs uppercase tracking-widest text-white/50">{children}</span>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="relative min-h-screen w-full font-display text-white">
      {/* Video background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="fixed inset-0 h-full w-full object-cover z-0"
      >
        <source src={VIDEO_URL} type="video/mp4" />
      </video>

      {/* Dark gradient overlay for readability on lower sections */}
      <div className="fixed inset-0 z-[1] bg-gradient-to-b from-transparent via-black/40 to-black/80" />

      {/* === HERO SECTION === */}
      <section className="relative z-10 flex min-h-screen w-full">
        {/* LEFT PANEL */}
        <div className="relative flex w-full flex-col lg:w-[52%]">
          <div className="liquid-glass-strong absolute inset-4 rounded-3xl lg:inset-6" />

          {/* Nav */}
          <nav className="relative z-10 flex items-center justify-between px-8 pt-8 lg:px-12 lg:pt-10">
            <div className="flex items-center gap-3">
              <Logo size={32} />
              <span className="text-2xl font-semibold tracking-tighter text-white">unidev</span>
            </div>
            <button
              onClick={() => setMenuOpen(true)}
              className="liquid-glass flex items-center gap-2 rounded-full px-5 py-2.5 text-sm text-white/80 transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              <Menu className="h-4 w-4" />
              Menu
            </button>
          </nav>

          {/* Hero center */}
          <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-8 text-center lg:px-12">
            <Logo size={80} />
            <h1 className="mt-8 max-w-xl text-5xl leading-[1.1] tracking-[-0.05em] text-white sm:text-6xl lg:text-7xl">
              Innovating the <em className="font-serif text-white/80">spirit of</em> Web3 &amp; AI
            </h1>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-white/60">
              Professional blockchain app development on Polygon and Ethereum, business system integrations, Unity SDK for games, and process automation.
            </p>
            <a
              href="#projects"
              className="liquid-glass-strong mt-8 flex items-center gap-3 rounded-full py-3 pl-6 pr-3 text-sm font-medium text-white transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              Explore Now
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/15">
                <Download className="h-3.5 w-3.5" />
              </span>
            </a>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              {SERVICE_PILLS.map((pill) => (
                <span key={pill} className="liquid-glass rounded-full px-4 py-2 text-xs text-white/80">
                  {pill}
                </span>
              ))}
            </div>
          </div>

          {/* Bottom quote */}
          <div className="relative z-10 flex flex-col items-center px-8 pb-10 lg:px-12 lg:pb-12">
            <span className="text-xs uppercase tracking-widest text-white/50">Visionary Design</span>
            <p className="mt-3 max-w-sm text-center text-lg leading-snug text-white/80">
              <span className="font-display">We imagined a realm</span>{' '}
              <span className="font-serif italic">with no ending.</span>
            </p>
            <div className="mt-4 flex w-full max-w-xs items-center gap-3">
              <span className="h-px flex-1 bg-white/20" />
              <span className="text-xs uppercase tracking-widest text-white/50">Marcus Aurelio</span>
              <span className="h-px flex-1 bg-white/20" />
            </div>
          </div>
        </div>

        {/* RIGHT PANEL (desktop only) */}
        <div className="relative hidden w-[48%] flex-col p-6 lg:flex">
          <div className="flex items-center justify-end gap-3">
            <div className="liquid-glass flex items-center gap-2 rounded-full px-4 py-2.5">
              {[
                { Icon: Twitter, label: 'Twitter' },
                { Icon: Linkedin, label: 'LinkedIn' },
                { Icon: Instagram, label: 'Instagram' },
              ].map(({ Icon, label }) => (
                <a key={label} href="#" aria-label={label} className="text-white transition-colors hover:text-white/80">
                  <IconContainer>
                    <Icon className="h-4 w-4" />
                  </IconContainer>
                </a>
              ))}
              <ArrowRight className="ml-1 h-4 w-4 text-white/60" />
            </div>
            <button className="liquid-glass flex items-center gap-2 rounded-full px-4 py-2.5 text-sm text-white/80 transition-transform duration-300 hover:scale-105 active:scale-95">
              <IconContainer>
                <Sparkles className="h-4 w-4" />
              </IconContainer>
              Account
            </button>
          </div>

          <div className="mt-8">
            <div className="liquid-glass w-56 rounded-2xl p-5">
              <h3 className="text-sm font-medium text-white">Enter our ecosystem</h3>
              <p className="mt-2 text-xs leading-relaxed text-white/60">
                Connect with a community building the future of decentralized technology.
              </p>
            </div>
          </div>

          <div className="mt-auto">
            <div className="liquid-glass rounded-[2.5rem] p-6">
              <div className="grid grid-cols-2 gap-4">
                {FEATURED_PROJECTS.map(({ icon: Icon, title, description, tag }) => (
                  <div key={title} className="liquid-glass rounded-3xl p-5 transition-transform duration-300 hover:scale-105">
                    <div className="flex items-center justify-between">
                      <IconContainer>
                        <Icon className="h-4 w-4" />
                      </IconContainer>
                      <span className="text-[10px] uppercase tracking-widest text-white/40">{tag}</span>
                    </div>
                    <h3 className="mt-4 text-base font-medium text-white">{title}</h3>
                    <p className="mt-1.5 text-xs leading-relaxed text-white/60">{description}</p>
                  </div>
                ))}
              </div>
              <div className="liquid-glass mt-4 flex items-center gap-4 rounded-3xl p-5 transition-transform duration-300 hover:scale-105">
                <img src={FLOWER_IMG} alt="Floral design" className="h-16 w-24 shrink-0 rounded-xl object-cover" />
                <div className="flex-1">
                  <h3 className="text-base font-medium text-white">Blockchain Identity</h3>
                  <p className="mt-1 text-xs leading-relaxed text-white/60">
                    ID + Wallet + Achievements on Polygon with Soulbound NFTs and ZK-Proofs.
                  </p>
                </div>
                <button
                  aria-label="Expand"
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition-transform duration-300 hover:scale-105 active:scale-95"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* === PROJECTS SECTION === */}
      <section id="projects" className="relative z-10 px-6 py-24 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col items-center text-center">
            <SectionLabel>Projects</SectionLabel>
            <h2 className="mt-4 text-4xl tracking-[-0.05em] text-white sm:text-5xl lg:text-6xl">
              Selected <em className="font-serif text-white/80">work</em>
            </h2>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-white/60">
              Five case studies spanning blockchain identity, AI vision, content automation, and enterprise integrations.
            </p>
          </div>

          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {ALL_PROJECTS.map((project) => {
              const Icon = project.icon;
              return (
                <div
                  key={project.title}
                  className="liquid-glass-strong group flex flex-col rounded-3xl p-6 transition-transform duration-300 hover:scale-105"
                >
                  <div className="flex items-center justify-between">
                    <IconContainer size="w-10 h-10">
                      <Icon className="h-5 w-5" />
                    </IconContainer>
                    {project.demoLabel && (
                      <span className="text-[10px] uppercase tracking-widest text-white/40">
                        {project.demoLabel}
                      </span>
                    )}
                  </div>
                  <h3 className="mt-5 text-lg font-medium text-white">{project.title}</h3>
                  <p className="mt-1 font-serif text-sm italic text-white/50">{project.subtitle}</p>
                  <p className="mt-3 flex-1 text-xs leading-relaxed text-white/60">
                    {project.description}
                  </p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span key={tag} className="liquid-glass rounded-full px-3 py-1.5 text-[10px] text-white/70">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <button className="mt-5 flex items-center gap-2 text-xs text-white/80 transition-colors hover:text-white">
                    Смотреть детали
                    <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* === EXPERTISE SECTION === */}
      <section id="expertise" className="relative z-10 px-6 py-24 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col items-center text-center">
            <SectionLabel>Expertise</SectionLabel>
            <h2 className="mt-4 text-4xl tracking-[-0.05em] text-white sm:text-5xl lg:text-6xl">
              Areas of <em className="font-serif text-white/80">expertise</em>
            </h2>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-white/60">
              Full-stack capabilities across frontend, backend, blockchain, AI, automation, and infrastructure.
            </p>
          </div>

          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {EXPERTISE_AREAS.map((area) => {
              const Icon = area.icon;
              return (
                <div key={area.title} className="liquid-glass rounded-3xl p-6 transition-transform duration-300 hover:scale-105">
                  <IconContainer size="w-10 h-10">
                    <Icon className="h-5 w-5" />
                  </IconContainer>
                  <h3 className="mt-5 text-lg font-medium text-white">{area.title}</h3>
                  <ul className="mt-4 space-y-2">
                    {area.items.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-xs text-white/60">
                        <span className="h-1 w-1 rounded-full bg-white/40" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* === TECH STACK SECTION === */}
      <section className="relative z-10 px-6 py-24 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col items-center text-center">
            <SectionLabel>Tech Stack</SectionLabel>
            <h2 className="mt-4 text-4xl tracking-[-0.05em] text-white sm:text-5xl lg:text-6xl">
              Tools of the <em className="font-serif text-white/80">trade</em>
            </h2>
          </div>

          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {TECH_STACK.map((category) => {
              const Icon = category.icon;
              return (
                <div key={category.label} className="liquid-glass rounded-3xl p-6 transition-transform duration-300 hover:scale-105">
                  <div className="flex items-center gap-3">
                    <IconContainer>
                      <Icon className="h-4 w-4" />
                    </IconContainer>
                    <h3 className="text-base font-medium text-white">{category.label}</h3>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {category.techs.map((tech) => (
                      <span key={tech} className="liquid-glass rounded-full px-3 py-1.5 text-[10px] text-white/70">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* === CONTACT / CTA SECTION === */}
      <section id="contact" className="relative z-10 px-6 py-24 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-3xl">
          <div className="liquid-glass-strong rounded-[2.5rem] p-10 text-center lg:p-16">
            <SectionLabel>Get in touch</SectionLabel>
            <h2 className="mt-6 text-4xl tracking-[-0.05em] text-white sm:text-5xl lg:text-6xl">
              Ready to start a <em className="font-serif text-white/80">project?</em>
            </h2>
            <p className="mt-6 max-w-md mx-auto text-sm leading-relaxed text-white/60">
              Обсудим задачу, предложим решение, реализуем под ключ. Быстрее всего — через Telegram.
            </p>

            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <a
                href="https://t.me/LUXury_CEO"
                target="_blank"
                rel="noopener noreferrer"
                className="liquid-glass-strong flex items-center gap-3 rounded-full py-3 pl-6 pr-3 text-sm font-medium text-white transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                <Send className="h-4 w-4" />
                Связаться через Telegram
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/15">
                  <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </a>
              <a
                href="mailto:admin@aliterra.space"
                className="liquid-glass flex items-center gap-2 rounded-full px-6 py-3 text-sm text-white/80 transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                <Mail className="h-4 w-4" />
                admin@aliterra.space
              </a>
            </div>

            <div className="mt-12 flex items-center justify-center gap-3">
              {[
                { Icon: Twitter, label: 'Twitter', href: '#' },
                { Icon: Linkedin, label: 'LinkedIn', href: '#' },
                { Icon: Instagram, label: 'Instagram', href: '#' },
              ].map(({ Icon, label, href }) => (
                <a key={label} href={href} aria-label={label} className="text-white transition-colors hover:text-white/80">
                  <IconContainer>
                    <Icon className="h-4 w-4" />
                  </IconContainer>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* === FOOTER === */}
      <footer className="relative z-10 px-6 py-12 lg:px-12">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="flex items-center gap-3">
            <Logo size={28} />
            <span className="text-lg font-semibold tracking-tighter text-white">unidev</span>
          </div>
          <p className="text-xs text-white/40">© 2026 UniDev • Web3, Blockchain &amp; Corporate Solutions</p>
          <div className="flex items-center gap-3">
            {[
              { Icon: Twitter, label: 'Twitter', href: '#' },
              { Icon: Linkedin, label: 'LinkedIn', href: '#' },
              { Icon: Instagram, label: 'Instagram', href: '#' },
            ].map(({ Icon, label, href }) => (
              <a key={label} href={href} aria-label={label} className="text-white/60 transition-colors hover:text-white">
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </footer>

      {/* Menu overlay */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md"
          onClick={() => setMenuOpen(false)}
        >
          <div className="liquid-glass-strong w-[90%] max-w-md rounded-3xl p-8" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <span className="text-lg font-medium text-white">Menu</span>
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="Close menu"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="mt-6 flex flex-col gap-1">
              {[
                { label: 'Home', href: '#' },
                { label: 'Projects', href: '#projects' },
                { label: 'Expertise', href: '#expertise' },
                { label: 'Contact', href: '#contact' },
              ].map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-xl px-4 py-3 text-lg text-white/80 transition-colors hover:bg-white/10 hover:text-white"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <div className="mt-6 border-t border-white/10 pt-6">
              <p className="text-xs uppercase tracking-widest text-white/40">Contact</p>
              <a
                href="https://t.me/LUXury_CEO"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 block text-sm text-white/80 transition-colors hover:text-white"
              >
                Telegram · @LUXury_CEO
              </a>
              <a href="mailto:admin@aliterra.space" className="mt-1 block text-sm text-white/80 transition-colors hover:text-white">
                admin@aliterra.space
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
