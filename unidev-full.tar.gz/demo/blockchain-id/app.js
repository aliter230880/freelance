// ============================================
// БЛОКЧЕЙН ID СИСТЕМА - ИНТЕРАКТИВНАЯ ДЕМОНСТРАЦИЯ
// ============================================

// Хранилище состояния (имитация blockchain через localStorage)
class BlockchainStorage {
    constructor() {
        this.prefix = 'blockchain_id_';
    }

    set(key, value) {
        localStorage.setItem(this.prefix + key, JSON.stringify(value));
    }

    get(key) {
        const value = localStorage.getItem(this.prefix + key);
        return value ? JSON.parse(value) : null;
    }

    remove(key) {
        localStorage.removeItem(this.prefix + key);
    }

    getAll() {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith(this.prefix)) {
                const cleanKey = key.replace(this.prefix, '');
                data[cleanKey] = this.get(cleanKey);
            }
        }
        return data;
    }
}

const storage = new BlockchainStorage();

// Глобальное состояние приложения
const appState = {
    currentWallet: null,
    currentIdentity: null,
    isGuardian: false,
    users: storage.get('users') || {},
    achievements: storage.get('achievements') || {},
    reports: storage.get('reports') || [],
    proposals: storage.get('proposals') || [],
    guardianActions: storage.get('guardianActions') || [],
    pilgrimageNFTs: storage.get('pilgrimageNFTs') || [],  // 🆕 Proof-of-Pilgrimage
    marketplaceTasks: storage.get('marketplaceTasks') || [],  // 🆕 Задачи
    trustedNodes: storage.get('trustedNodes') || [],  // 🆕 Узлы верификации
    currentLanguage: storage.get('language') || 'ru'  // 🆕 Язык
};

// Адреса Хранителей (секретные)
const GUARDIANS = [
    '0xGuardian1SecretAddress123456789abcdef',
    '0xGuardian2SecretAddress987654321fedcba',
    '0xGuardian3SecretAddressABCDEF0123456789'
];

// Типы нарушений и штрафы
const VIOLATIONS = {
    SPAM: { penalty: 5, name: 'Спам' },
    HARASSMENT: { penalty: 20, name: 'Оскорбления' },
    FRAUD: { penalty: 100, name: 'Мошенничество', autoBan: true },
    ILLEGAL_CONTENT: { penalty: 100, name: 'Незаконный контент', permaBan: true }
};

// Девизы Pilgrim (Order of Christ's Pilgrims)
const PILGRIM_MOTTOS = {
    SERVICE: { la: 'Non imperium, sed ministerium', ru: 'Не власть, а служение', en: 'Not power, but service' },
    JOURNEY: { la: 'In itinere Deus habitat', ru: 'Бог живёт в пути', en: 'God dwells on the way' },
    GIFT: { la: 'Peregrinus non onus, sed donum', ru: 'Паломник не бремя, а дар', en: 'A pilgrim is not a burden, but a gift' },
    LOVE: { la: 'Caritas in veritate et in opere', ru: 'Любовь в истине и деле', en: 'Love in truth and in deed' },
    PEACE: { la: 'Beati pacifici, fratres dialogi', ru: 'Блаженны миротворцы', en: 'Blessed are the peacemakers' },
    DEPTHS: { la: 'Duc in altum', ru: 'Плыви в глубину', en: 'Sail into the depths' }
};

// Типы задач Marketplace
const TASK_TYPES = {
    PILGRIMAGE: { name: 'Паломничество', icon: '🚶', price: 50 },
    DELIVERY: { name: 'Доставка', icon: '📦', price: 30 },
    DOCUMENTS: { name: 'Документы', icon: '📄', price: 40 },
    PHOTOGRAPHY: { name: 'Фотография', icon: '📷', price: 25 },
    RESEARCH: { name: 'Исследование', icon: '🔍', price: 35 },
    ESCORT: { name: 'Сопровождение', icon: '🤝', price: 60 }
};

// Уровни пользователей
const USER_LEVELS = {
    VERIFIED: 'verified',
    PSEUDONYMOUS: 'pseudonymous',
    ANONYMOUS: 'anonymous',
    PILGRIM: 'pilgrim'  // 🆕 Без государства, community-verification
};

// ============================================
// УТИЛИТЫ
// ============================================

function generateAddress() {
    return '0x' + Array.from({ length: 40 }, () => 
        Math.floor(Math.random() * 16).toString(16)
    ).join('');
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    const container = document.getElementById('notifications');
    container.appendChild(notification);
    
    notification.addEventListener('click', () => {
        notification.style.animation = 'slideOutRight 0.3s';
        setTimeout(() => notification.remove(), 300);
    });
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

function openModal(title, content) {
    const modal = document.getElementById('modal');
    const modalBody = document.getElementById('modalBody');
    
    modalBody.innerHTML = `
        <h2>${title}</h2>
        ${content}
    `;
    
    modal.style.display = 'block';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

// ============================================
// ФУНКЦИИ БЛОКЧЕЙНА (MOCK)
// ============================================

function connectWallet() {
    const address = generateAddress();
    appState.currentWallet = address;
    
    document.getElementById('currentWallet').textContent = 
        address.substring(0, 6) + '...' + address.substring(38);
    
    // Проверка на Хранителя
    if (GUARDIANS.includes(address)) {
        appState.isGuardian = true;
        showNotification('⚠️ Добро пожаловать, Хранитель!', 'info');
    }
    
    showNotification('Кошелёк подключён!', 'success');
    updateUI();
}

function createIdentity(level, name, email) {
    if (!appState.currentWallet) {
        showNotification('Сначала подключите кошелёк!', 'error');
        return false;
    }
    
    const identity = {
        address: appState.currentWallet,
        level: level,
        name: name || 'Аноним',
        email: email || '',
        reputation: {
            transparency: level === USER_LEVELS.VERIFIED ? 80 : (level === USER_LEVELS.PILGRIM ? 70 : (level === USER_LEVELS.PSEUDONYMOUS ? 30 : 0)),
            contribution: 0,
            trust: 0,
            risk: 0
        },
        stake: level === USER_LEVELS.VERIFIED ? 100 : (level === USER_LEVELS.PILGRIM ? 50 : (level === USER_LEVELS.PSEUDONYMOUS ? 10 : 0)),
        achievements: [],
        violations: [],
        createdAt: Date.now(),
        status: 'active',
        verificationMethod: level === USER_LEVELS.PILGRIM ? 'community' : 'kyc'  // 🆕
    };
    
    appState.currentIdentity = identity;
    appState.users[appState.currentWallet] = identity;
    storage.set('users', appState.users);
    
    return true;
}

function calculateTotalReputation(identity) {
    const rep = identity.reputation;
    return rep.transparency + rep.contribution + rep.trust - rep.risk;
}

function getReputationLevel(score) {
    if (score >= 100) return { text: 'Отличная', color: '#10b981', emoji: '🟢' };
    if (score >= 50) return { text: 'Хорошая', color: '#f59e0b', emoji: '🟡' };
    if (score >= 10) return { text: 'Нейтральная', color: '#06b6d4', emoji: '🔵' };
    if (score >= 0) return { text: 'Низкая', color: '#ef4444', emoji: '🔴' };
    return { text: 'Забанен', color: '#000', emoji: '⚫' };
}

function addAchievement(address, achievementType) {
    const user = appState.users[address];
    if (!user) return;
    
    const achievement = {
        type: achievementType,
        timestamp: Date.now()
    };
    
    user.achievements.push(achievement);
    user.reputation.contribution += 10;
    storage.set('users', appState.users);
    
    if (address === appState.currentWallet) {
        showNotification(`🏆 Получено достижение: ${achievementType}!`, 'success');
        updateUI();
    }
}

function reportUser(reporterAddress, targetAddress, violationType, description) {
    const report = {
        id: Date.now(),
        reporter: reporterAddress,
        target: targetAddress,
        type: violationType,
        description: description,
        status: 'pending',
        votes: [],
        createdAt: Date.now()
    };
    
    appState.reports.push(report);
    storage.set('reports', appState.reports);
    
    // Автоматическая проверка на очевидные нарушения
    if (violationType === 'ILLEGAL_CONTENT' || violationType === 'FRAUD') {
        processReport(report.id, true);
    }
    
    showNotification('Жалоба отправлена на модерацию', 'info');
    return report;
}

function processReport(reportId, approved) {
    const report = appState.reports.find(r => r.id === reportId);
    if (!report) return;
    
    report.status = approved ? 'approved' : 'rejected';
    
    if (approved) {
        const targetUser = appState.users[report.target];
        if (!targetUser) return;
        
        const violation = VIOLATIONS[report.type];
        
        // Применяем штраф
        targetUser.stake -= violation.penalty;
        targetUser.reputation.risk += violation.penalty;
        targetUser.violations.push({
            type: report.type,
            penalty: violation.penalty,
            timestamp: Date.now()
        });
        
        // Проверяем на бан
        if (violation.permaBan || targetUser.stake <= 0) {
            targetUser.status = 'banned';
            showNotification(`Пользователь забанен за: ${violation.name}`, 'error');
        } else if (violation.autoBan) {
            targetUser.status = 'temp_banned';
            setTimeout(() => {
                targetUser.status = 'active';
                storage.set('users', appState.users);
            }, 7 * 24 * 60 * 60 * 1000); // 7 дней
            showNotification(`Пользователь временно забанен за: ${violation.name}`, 'error');
        }
        
        storage.set('users', appState.users);
    }
    
    storage.set('reports', appState.reports);
    updateUI();
}

// ============================================
// ФУНКЦИИ ХРАНИТЕЛЕЙ (GUARDIAN)
// ============================================

function guardianEmergencyPause() {
    if (!appState.isGuardian) return;
    
    const action = {
        type: 'emergency_pause',
        guardian: appState.currentWallet,
        timestamp: Date.now(),
        reason: prompt('Причина экстренной приостановки:')
    };
    
    appState.guardianActions.push(action);
    storage.set('guardianActions', appState.guardianActions);
    storage.set('systemPaused', true);
    
    showNotification('⚠️ Система приостановлена Хранителем', 'error');
}

function guardianEmergencyBan(targetAddress) {
    if (!appState.isGuardian) return;
    
    const user = appState.users[targetAddress];
    if (!user) return;
    
    const action = {
        type: 'emergency_ban',
        guardian: appState.currentWallet,
        target: targetAddress,
        timestamp: Date.now(),
        reason: prompt('Причина экстренного бана:')
    };
    
    user.status = 'guardian_banned';
    user.stake = 0;
    
    appState.guardianActions.push(action);
    storage.set('guardianActions', appState.guardianActions);
    storage.set('users', appState.users);
    
    showNotification(`⚠️ Пользователь забанен Хранителем`, 'error');
}

function guardianEmergencyUnpause() {
    if (!appState.isGuardian) return;
    
    storage.remove('systemPaused');
    showNotification('✅ Система восстановлена Хранителем', 'success');
}

// ============================================
// DAO ФУНКЦИИ
// ============================================

function createProposal(title, description, type) {
    if (!appState.currentIdentity || appState.currentIdentity.level !== USER_LEVELS.VERIFIED) {
        showNotification('Только верифицированные пользователи могут создавать предложения', 'error');
        return;
    }
    
    const proposal = {
        id: Date.now(),
        title: title,
        description: description,
        type: type,
        creator: appState.currentWallet,
        votesFor: 0,
        votesAgainst: 0,
        voters: [],
        status: 'active',
        createdAt: Date.now(),
        endsAt: Date.now() + (7 * 24 * 60 * 60 * 1000) // 7 дней
    };
    
    appState.proposals.push(proposal);
    storage.set('proposals', appState.proposals);
    
    showNotification('Предложение создано!', 'success');
    updateUI();
}

function voteOnProposal(proposalId, vote) {
    if (!appState.currentIdentity || appState.currentIdentity.level !== USER_LEVELS.VERIFIED) {
        showNotification('Только верифицированные пользователи могут голосовать', 'error');
        return;
    }
    
    const proposal = appState.proposals.find(p => p.id === proposalId);
    if (!proposal) return;
    
    if (proposal.voters.includes(appState.currentWallet)) {
        showNotification('Вы уже проголосовали!', 'error');
        return;
    }
    
    if (vote) {
        proposal.votesFor++;
    } else {
        proposal.votesAgainst++;
    }
    
    proposal.voters.push(appState.currentWallet);
    storage.set('proposals', appState.proposals);
    
    showNotification('Ваш голос учтён!', 'success');
    updateUI();
}

// ============================================
// UI ОБНОВЛЕНИЕ
// ============================================

function updateUI() {
    updateIdentityTab();
    updateWalletTab();
    updateAchievementsTab();
    updatePilgrimageTab();
    updateMarketplaceTab();
    updateReputationTab();
    updateModerationTab();
    updateDAOTab();
}

function updateIdentityTab() {
    const content = document.getElementById('identityContent');
    
    if (!appState.currentIdentity) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">👤</div>
                <p>Создайте свою личность для начала работы</p>
                <button class="btn btn-primary" onclick="showCreateIdentityModal()">Создать личность</button>
            </div>
        `;
        return;
    }
    
    const identity = appState.currentIdentity;
    const totalRep = calculateTotalReputation(identity);
    const repLevel = getReputationLevel(totalRep);
    
    const levelNames = {
        verified: '1️⃣ Верифицированный',
        pseudonymous: '2️⃣ Псевдонимный',
        anonymous: '3️⃣ Анонимный',
        pilgrim: '🐚 Паломник'
    };
    
    content.innerHTML = `
        <div class="identity-info">
            <div class="identity-header">
                <h3>${identity.name}</h3>
                <span class="identity-level">${levelNames[identity.level]}</span>
            </div>
            <div class="identity-details">
                <p><strong>Адрес:</strong> ${identity.address.substring(0, 10)}...${identity.address.substring(36)}</p>
                <p><strong>Email:</strong> ${identity.email || 'Не указан'}</p>
                <p><strong>Статус:</strong> <span class="status-${identity.status}">${identity.status}</span></p>
                <p><strong>Стейк:</strong> ${identity.stake} токенов</p>
                <p><strong>Репутация:</strong> ${repLevel.emoji} ${totalRep} (${repLevel.text})</p>
                <p><strong>Достижений:</strong> ${identity.achievements.length}</p>
                <p><strong>Создано:</strong> ${new Date(identity.createdAt).toLocaleDateString()}</p>
            </div>
        </div>
    `;
}

function updateWalletTab() {
    const content = document.getElementById('walletContent');
    
    if (!appState.currentWallet) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">💰</div>
                <p>Подключите кошелёк для просмотра баланса</p>
                <button class="btn btn-primary" onclick="connectWallet()">Подключить кошелёк</button>
            </div>
        `;
        return;
    }
    
    const balance = appState.currentIdentity ? appState.currentIdentity.stake : 0;
    
    content.innerHTML = `
        <div class="wallet-info">
            <div class="wallet-header-row">
                <div class="balance-card">
                    <h3>Баланс токенов</h3>
                    <div class="balance-amount">${balance}</div>
                    <p class="balance-usd">≈ $${(balance * 0.5).toFixed(2)} USD</p>
                </div>
                
                <div class="qr-card">
                    <h4>QR для мобильного</h4>
                    <div class="qr-code" id="walletQR">
                        <svg viewBox="0 0 100 100" width="120" height="120">
                            <rect x="0" y="0" width="100" height="100" fill="white"/>
                            <rect x="10" y="10" width="15" height="15" fill="black"/>
                            <rect x="75" y="10" width="15" height="15" fill="black"/>
                            <rect x="10" y="75" width="15" height="15" fill="black"/>
                            <rect x="30" y="30" width="5" height="5" fill="black"/>
                            <rect x="40" y="30" width="5" height="5" fill="black"/>
                            <rect x="50" y="30" width="5" height="5" fill="black"/>
                            <rect x="60" y="30" width="5" height="5" fill="black"/>
                            <rect x="35" y="45" width="5" height="5" fill="black"/>
                            <rect x="55" y="45" width="5" height="5" fill="black"/>
                            <rect x="30" y="60" width="5" height="5" fill="black"/>
                            <rect x="50" y="60" width="5" height="5" fill="black"/>
                            <rect x="70" y="60" width="5" height="5" fill="black"/>
                        </svg>
                    </div>
                    <p class="qr-note">Отсканируйте для подключения</p>
                </div>
            </div>
            
            <div class="actions">
                <button class="btn btn-primary" onclick="showStakeModal()">💎 Застейкать</button>
                <button class="btn btn-secondary" onclick="showSendModal()">📤 Отправить</button>
                <button class="btn btn-secondary" onclick="showReceiveModal()">📥 Получить</button>
            </div>
            
            <div class="wallet-details">
                <h4>Детали кошелька</h4>
                <div class="detail-row">
                    <span>Адрес:</span>
                    <span class="mono">${appState.currentWallet.substring(0, 15)}...${appState.currentWallet.substring(35)}</span>
                </div>
                <div class="detail-row">
                    <span>Сеть:</span>
                    <span>Polygon Mainnet</span>
                </div>
                <div class="detail-row">
                    <span>Токены в стейке:</span>
                    <span>${balance} токенов</span>
                </div>
            </div>
            
            <div class="transactions">
                <h4>Последние транзакции</h4>
                <p class="text-secondary">Пока нет транзакций</p>
            </div>
        </div>
    `;
}

function updateAchievementsTab() {
    const content = document.getElementById('achievementsContent');
    
    if (!appState.currentIdentity || appState.currentIdentity.achievements.length === 0) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">🏆</div>
                <p>Пока нет достижений. Начните взаимодействовать с системой!</p>
                <button class="btn btn-primary" onclick="simulateActivity()">🎮 Симулировать активность</button>
            </div>
        `;
        return;
    }
    
    const achievements = appState.currentIdentity.achievements;
    const achievementsList = achievements.map(a => `
        <div class="achievement-card">
            <div class="achievement-icon">🏆</div>
            <div class="achievement-info">
                <h4>${a.type}</h4>
                <p>${new Date(a.timestamp).toLocaleDateString()}</p>
            </div>
        </div>
    `).join('');
    
    content.innerHTML = `
        <div class="achievements-grid">
            ${achievementsList}
        </div>
        <button class="btn btn-secondary" onclick="simulateActivity()">🎮 Симулировать активность</button>
    `;
}

function updateReputationTab() {
    const content = document.getElementById('reputationContent');
    
    if (!appState.currentIdentity) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">⭐</div>
                <p>Создайте личность для отслеживания репутации</p>
            </div>
        `;
        return;
    }
    
    const rep = appState.currentIdentity.reputation;
    const total = calculateTotalReputation(appState.currentIdentity);
    const level = getReputationLevel(total);
    
    content.innerHTML = `
        <div class="reputation-dashboard">
            <div class="reputation-total">
                <h3>Общая репутация</h3>
                <div class="reputation-score" style="color: ${level.color}">
                    ${level.emoji} ${total}
                </div>
                <p>${level.text}</p>
            </div>
            
            <div class="reputation-breakdown">
                <div class="rep-item">
                    <div class="rep-label">🔍 Прозрачность</div>
                    <div class="rep-bar">
                        <div class="rep-fill" style="width: ${(rep.transparency/100)*100}%; background: #10b981;"></div>
                    </div>
                    <div class="rep-value">${rep.transparency}</div>
                </div>
                
                <div class="rep-item">
                    <div class="rep-label">💎 Вклад</div>
                    <div class="rep-bar">
                        <div class="rep-fill" style="width: ${(rep.contribution/100)*100}%; background: #8b5cf6;"></div>
                    </div>
                    <div class="rep-value">${rep.contribution}</div>
                </div>
                
                <div class="rep-item">
                    <div class="rep-label">🤝 Доверие</div>
                    <div class="rep-bar">
                        <div class="rep-fill" style="width: ${(rep.trust/100)*100}%; background: #06b6d4;"></div>
                    </div>
                    <div class="rep-value">${rep.trust}</div>
                </div>
                
                <div class="rep-item">
                    <div class="rep-label">⚠️ Риск</div>
                    <div class="rep-bar">
                        <div class="rep-fill" style="width: ${(rep.risk/100)*100}%; background: #ef4444;"></div>
                    </div>
                    <div class="rep-value">-${rep.risk}</div>
                </div>
            </div>
        </div>
    `;
}

function updateModerationTab() {
    const content = document.getElementById('moderationContent');
    
    if (!appState.currentIdentity || appState.currentIdentity.level !== USER_LEVELS.VERIFIED) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">🛡️</div>
                <p>Для участия в модерации требуется верифицированный аккаунт</p>
            </div>
        `;
        return;
    }
    
    const pendingReports = appState.reports.filter(r => r.status === 'pending');
    
    if (pendingReports.length === 0) {
        content.innerHTML = `
            <div class="moderation-content">
                <p>Нет жалоб на модерации</p>
                <button class="btn btn-secondary" onclick="createTestReport()">Создать тестовую жалобу</button>
            </div>
        `;
        return;
    }
    
    const reportsList = pendingReports.map(report => {
        const violation = VIOLATIONS[report.type];
        return `
            <div class="report-card">
                <h4>${violation.name}</h4>
                <p><strong>Нарушитель:</strong> ${report.target.substring(0, 10)}...</p>
                <p><strong>Описание:</strong> ${report.description}</p>
                <p><strong>Штраф:</strong> ${violation.penalty} токенов</p>
                <div class="report-actions">
                    <button class="btn btn-primary" onclick="processReport(${report.id}, true)">✅ Подтвердить</button>
                    <button class="btn btn-secondary" onclick="processReport(${report.id}, false)">❌ Отклонить</button>
                </div>
            </div>
        `;
    }).join('');
    
    content.innerHTML = `
        <div class="moderation-content">
            <h3>Ожидающие проверки (${pendingReports.length})</h3>
            ${reportsList}
        </div>
    `;
}

function updateDAOTab() {
    const content = document.getElementById('daoContent');
    
    if (!appState.currentIdentity || appState.currentIdentity.level !== USER_LEVELS.VERIFIED) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">⚖️</div>
                <p>Для участия в голосовании требуется верифицированный аккаунт</p>
            </div>
        `;
        return;
    }
    
    const activeProposals = appState.proposals.filter(p => p.status === 'active');
    
    const proposalsList = activeProposals.length > 0 ? activeProposals.map(proposal => {
        const totalVotes = proposal.votesFor + proposal.votesAgainst;
        const percentFor = totalVotes > 0 ? (proposal.votesFor / totalVotes * 100).toFixed(1) : 0;
        const hasVoted = proposal.voters.includes(appState.currentWallet);
        
        return `
            <div class="proposal-card">
                <h4>${proposal.title}</h4>
                <p>${proposal.description}</p>
                <div class="vote-stats">
                    <div class="vote-bar">
                        <div class="vote-for" style="width: ${percentFor}%"></div>
                    </div>
                    <p>За: ${proposal.votesFor} | Против: ${proposal.votesAgainst}</p>
                </div>
                ${hasVoted ? 
                    '<p class="voted-badge">✓ Вы проголосовали</p>' : 
                    `<div class="vote-actions">
                        <button class="btn btn-primary" onclick="voteOnProposal(${proposal.id}, true)">👍 За</button>
                        <button class="btn btn-secondary" onclick="voteOnProposal(${proposal.id}, false)">👎 Против</button>
                    </div>`
                }
            </div>
        `;
    }).join('') : '<p>Нет активных предложений</p>';
    
    content.innerHTML = `
        <div class="dao-content">
            <button class="btn btn-primary" onclick="showCreateProposalModal()">Создать предложение</button>
            <h3 style="margin-top: 2rem;">Активные предложения</h3>
            ${proposalsList}
        </div>
    `;
}

// ============================================
// МОДАЛЬНЫЕ ОКНА
// ============================================

function showCreateIdentityModal() {
    openModal('Создать личность', `
        <form id="createIdentityForm">
            <div class="form-group">
                <label>Уровень верификации:</label>
                <select id="levelSelect" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
                    <option value="verified">1️⃣ Верифицированный (100 токенов стейк, все возможности)</option>
                    <option value="pseudonymous">2️⃣ Псевдонимный (10 токенов стейк, базовые функции)</option>
                    <option value="anonymous">3️⃣ Анонимный (только просмотр)</option>
                    <option value="pilgrim">🐚 Паломник (community-verification, для displaced people)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Имя:</label>
                <input type="text" id="nameInput" placeholder="Ваше имя" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            </div>
            <div class="form-group">
                <label>Email (опционально):</label>
                <input type="email" id="emailInput" placeholder="your@email.com" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            </div>
            <div class="motto-display" style="text-align: center; padding: 1rem; background: rgba(139, 92, 246, 0.1); border-radius: 0.5rem; margin-top: 1rem; font-style: italic;">
                <p style="color: var(--accent-fuchsia);">"${PILGRIM_MOTTOS.JOURNEY.la}"</p>
                <p style="color: var(--text-secondary); font-size: 0.875rem;">${PILGRIM_MOTTOS.JOURNEY.ru}</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Создать</button>
        </form>
    `);
    
    document.getElementById('createIdentityForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const level = document.getElementById('levelSelect').value;
        const name = document.getElementById('nameInput').value;
        const email = document.getElementById('emailInput').value;
        
        if (createIdentity(level, name, email)) {
            showNotification('Личность создана!', 'success');
            closeModal();
            updateUI();
        }
    });
}

function showCreateProposalModal() {
    openModal('Создать предложение DAO', `
        <form id="createProposalForm">
            <div class="form-group">
                <label>Заголовок:</label>
                <input type="text" id="proposalTitle" placeholder="Название предложения" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            </div>
            <div class="form-group">
                <label>Описание:</label>
                <textarea id="proposalDescription" placeholder="Подробное описание" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet); min-height: 100px;"></textarea>
            </div>
            <div class="form-group">
                <label>Тип:</label>
                <select id="proposalType" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
                    <option value="rules">Изменение правил</option>
                    <option value="penalty">Изменение штрафов</option>
                    <option value="appeal">Апелляция</option>
                    <option value="funding">Распределение фондов</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Создать предложение</button>
        </form>
    `);
    
    document.getElementById('createProposalForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('proposalTitle').value;
        const description = document.getElementById('proposalDescription').value;
        const type = document.getElementById('proposalType').value;
        
        createProposal(title, description, type);
        closeModal();
    });
}

function createTestReport() {
    const testAddress = generateAddress();
    reportUser(
        appState.currentWallet,
        testAddress,
        'SPAM',
        'Тестовая жалоба на спам'
    );
    updateUI();
}

function simulateActivity() {
    if (!appState.currentIdentity) return;
    
    const activities = ['Helper', 'Moderator', 'Contributor', 'Explorer', 'Friendly'];
    const randomActivity = activities[Math.floor(Math.random() * activities.length)];
    
    addAchievement(appState.currentWallet, randomActivity);
}

function showStakeModal() {
    openModal('Застейкать токены', `
        <p>Застейкайте токены для увеличения репутации и получения APY</p>
        <form id="stakeForm">
            <input type="number" id="stakeAmount" placeholder="Количество токенов" min="1" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            <p style="margin-top: 1rem; color: var(--text-secondary);">APY: 5% + бонус за репутацию</p>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Застейкать</button>
        </form>
    `);
    
    document.getElementById('stakeForm').addEventListener('submit', (e) => {
        e.preventDefault();
        showNotification('Токены застейканы!', 'success');
        closeModal();
    });
}

function showSendModal() {
    openModal('Отправить токены', `
        <form id="sendForm">
            <input type="text" id="sendAddress" placeholder="Адрес получателя (0x...)" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet); margin-bottom: 1rem;">
            <input type="number" id="sendAmount" placeholder="Количество токенов" min="1" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Отправить</button>
        </form>
    `);
    
    document.getElementById('sendForm').addEventListener('submit', (e) => {
        e.preventDefault();
        showNotification('Транзакция отправлена!', 'success');
        closeModal();
    });
}

// ============================================
// ПАНЕЛЬ ХРАНИТЕЛЕЙ
// ============================================

function openGuardianPanel() {
    if (!appState.isGuardian) {
        showNotification('Доступ запрещён!', 'error');
        return;
    }
    
    const panel = document.getElementById('guardianPanel');
    const guardianContent = document.getElementById('guardianContent');
    
    const allUsers = Object.values(appState.users);
    const usersList = allUsers.map(user => `
        <div class="guardian-user-card">
            <p><strong>${user.name}</strong></p>
            <p>${user.address.substring(0, 15)}...</p>
            <p>Статус: ${user.status}</p>
            <button class="btn btn-danger" onclick="guardianEmergencyBan('${user.address}')">Забанить</button>
        </div>
    `).join('');
    
    guardianContent.innerHTML = `
        <div class="guardian-actions">
            <h3>Экстренные действия</h3>
            <button class="btn btn-danger" onclick="guardianEmergencyPause()">⏸️ Приостановить систему</button>
            <button class="btn btn-primary" onclick="guardianEmergencyUnpause()">▶️ Восстановить систему</button>
        </div>
        
        <div class="guardian-users">
            <h3>Все пользователи (${allUsers.length})</h3>
            ${usersList || '<p>Нет пользователей</p>'}
        </div>
        
        <div class="guardian-logs">
            <h3>История действий Хранителей</h3>
            ${appState.guardianActions.map(action => `
                <div class="guardian-log">
                    <p><strong>${action.type}</strong></p>
                    <p>${new Date(action.timestamp).toLocaleString()}</p>
                    <p>Причина: ${action.reason}</p>
                </div>
            `).join('') || '<p>Нет действий</p>'}
        </div>
    `;
    
    panel.style.display = 'block';
}

function closeGuardianPanel() {
    document.getElementById('guardianPanel').style.display = 'none';
}

// ============================================
// ИНИЦИАЛИЗАЦИЯ И СОБЫТИЯ
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    // Навигация по табам
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.getAttribute('data-tab');
            
            // Удаляем active у всех табов и контента
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            // Добавляем active к выбранным
            tab.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        });
    });
    
    // Кнопки подключения кошелька
    document.getElementById('connectWallet').addEventListener('click', connectWallet);
    document.getElementById('connectWalletBtn').addEventListener('click', connectWallet);
    
    // Кнопки создания личности
    document.getElementById('createIdentity').addEventListener('click', showCreateIdentityModal);
    document.getElementById('createIdentityBtn').addEventListener('click', showCreateIdentityModal);
    
    // Закрытие модального окна
    document.querySelector('.close').addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        const modal = document.getElementById('modal');
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // Закрытие панели Хранителей
    document.querySelector('.guardian-close').addEventListener('click', closeGuardianPanel);
    
    // Секретная комбинация для панели Хранителей (Ctrl+Shift+G)
    let ctrlPressed = false;
    let shiftPressed = false;
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Control') ctrlPressed = true;
        if (e.key === 'Shift') shiftPressed = true;
        
        if (ctrlPressed && shiftPressed && e.key.toLowerCase() === 'g') {
            openGuardianPanel();
        }
    });
    
    document.addEventListener('keyup', (e) => {
        if (e.key === 'Control') ctrlPressed = false;
        if (e.key === 'Shift') shiftPressed = false;
    });
    
    // Анимация статистики
    animateStats();
    
    // Начальное обновление UI
    updateUI();
});

// ============================================
// ДОПОЛНИТЕЛЬНЫЕ ЭФФЕКТЫ
// ============================================

function animateStats() {
    const stats = [
        { id: 'totalUsers', target: 1247, suffix: '' },
        { id: 'totalTransactions', target: 15892, suffix: '' },
        { id: 'totalAchievements', target: 8456, suffix: '' }
    ];
    
    stats.forEach(stat => {
        const element = document.getElementById(stat.id);
        if (!element) return;
        
        let current = 0;
        const increment = stat.target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= stat.target) {
                element.textContent = stat.target.toLocaleString() + stat.suffix;
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current).toLocaleString() + stat.suffix;
            }
        }, 30);
    });
}

// Добавляем CSS для slideOutRight анимации
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
    
    .form-group {
        margin-bottom: 1.5rem;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--text-secondary);
        font-weight: 500;
    }
    
    .identity-info, .wallet-info, .reputation-dashboard, .moderation-content, .dao-content {
        padding: 1.5rem;
    }
    
    .identity-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }
    
    .identity-level {
        padding: 0.5rem 1rem;
        background: var(--accent-violet);
        border-radius: 0.5rem;
        font-size: 0.875rem;
    }
    
    .identity-details p {
        margin: 0.75rem 0;
        padding: 0.75rem;
        background: var(--bg-card);
        border-radius: 0.5rem;
    }
`;
document.head.appendChild(style);

// Дополнительные стили для компонентов
const additionalStyles = document.createElement('style');
additionalStyles.textContent = `
    .balance-card {
        background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(217, 70, 239, 0.2));
        padding: 2rem;
        border-radius: 1rem;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .balance-amount {
        font-size: 3rem;
        font-weight: 700;
        background: linear-gradient(135deg, var(--accent-violet), var(--accent-cyan));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin: 1rem 0;
    }
    
    .balance-usd {
        color: var(--text-secondary);
        font-size: 1.25rem;
    }
    
    .actions {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
    }
    
    .actions .btn {
        flex: 1;
    }
    
    .transactions h4 {
        margin-bottom: 1rem;
    }
    
    .achievement-card {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1.5rem;
        background: var(--bg-card);
        border-radius: 0.75rem;
        transition: var(--transition);
        cursor: pointer;
    }
    
    .achievement-card:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-hover);
    }
    
    .achievement-icon {
        font-size: 2rem;
    }
    
    .achievements-grid {
        display: grid;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .reputation-total {
        text-align: center;
        padding: 2rem;
        background: var(--bg-card);
        border-radius: 1rem;
        margin-bottom: 2rem;
    }
    
    .reputation-score {
        font-size: 4rem;
        font-weight: 700;
        margin: 1rem 0;
    }
    
    .reputation-breakdown {
        display: grid;
        gap: 1.5rem;
    }
    
    .rep-item {
        display: grid;
        grid-template-columns: 120px 1fr 60px;
        align-items: center;
        gap: 1rem;
    }
    
    .rep-bar {
        height: 20px;
        background: var(--bg-card);
        border-radius: 10px;
        overflow: hidden;
    }
    
    .rep-fill {
        height: 100%;
        transition: width 0.5s ease;
    }
`;
document.head.appendChild(additionalStyles);

// Еще больше стилей для компонентов
const moreStyles = document.createElement('style');
moreStyles.textContent = `
    .report-card, .proposal-card {
        padding: 1.5rem;
        background: var(--bg-card);
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        border-left: 4px solid var(--accent-violet);
    }
    
    .report-card h4, .proposal-card h4 {
        margin-bottom: 1rem;
        color: var(--accent-fuchsia);
    }
    
    .report-actions, .vote-actions {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
    }
    
    .vote-stats {
        margin: 1rem 0;
    }
    
    .vote-bar {
        height: 30px;
        background: var(--bg-secondary);
        border-radius: 15px;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }
    
    .vote-for {
        height: 100%;
        background: linear-gradient(90deg, var(--success), var(--accent-cyan));
        transition: width 0.5s ease;
    }
    
    .voted-badge {
        color: var(--success);
        font-weight: 600;
        padding: 0.5rem;
        background: rgba(16, 185, 129, 0.2);
        border-radius: 0.5rem;
        text-align: center;
    }
    
    .guardian-user-card {
        padding: 1rem;
        background: rgba(139, 92, 246, 0.1);
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        border: 1px solid var(--accent-violet);
    }
    
    .guardian-user-card p {
        margin: 0.25rem 0;
    }
    
    .guardian-actions, .guardian-users, .guardian-logs {
        margin-bottom: 2rem;
    }
    
    .guardian-log {
        padding: 1rem;
        background: rgba(245, 158, 11, 0.1);
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        border-left: 3px solid var(--warning);
    }
    
    .text-secondary {
        color: var(--text-secondary);
    }
    
    .status-active {
        color: var(--success);
    }
    
    .status-banned, .status-temp_banned, .status-guardian_banned {
        color: var(--danger);
    }
    
    .btn-danger {
        background: var(--danger);
        color: white;
    }
    
    .btn-danger:hover {
        transform: translateY(-2px) scale(1.02);
        box-shadow: 0 6px 20px rgba(239, 68, 68, 0.5);
    }
`;
document.head.appendChild(moreStyles);

console.log('🚀 Блокчейн ID система загружена!');
console.log('💡 Нажмите Ctrl+Shift+G для доступа к панели Хранителей (если вы Хранитель)');

// ============================================
// ZERO-KNOWLEDGE PROOFS (MOCK)
// ============================================

function generateZKProof(claim, value) {
    // Имитация ZK-Proof - в реальности это сложная криптография
    const proof = {
        claim: claim,
        hash: Array.from({ length: 64 }, () => 
            Math.floor(Math.random() * 16).toString(16)
        ).join(''),
        timestamp: Date.now(),
        verified: true
    };
    
    return proof;
}

function proveAge() {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const proof = generateZKProof('age_over_18', true);
    
    document.getElementById('ageProof').innerHTML = `
        <div class="proof-success">
            <p>✅ ZK-Proof создан!</p>
            <p class="proof-hash">Hash: ${proof.hash.substring(0, 20)}...</p>
            <p class="proof-claim">Подтверждено: Возраст &gt; 18 лет</p>
            <p class="proof-note">Дата рождения НЕ раскрыта</p>
        </div>
    `;
    
    showNotification('ZK-Proof возраста создан!', 'success');
}

function proveCitizenship() {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const countries = ['Россия', 'США', 'Германия', 'Франция', 'Япония'];
    const country = countries[Math.floor(Math.random() * countries.length)];
    
    const proof = generateZKProof('citizenship', country);
    
    document.getElementById('citizenshipProof').innerHTML = `
        <div class="proof-success">
            <p>✅ ZK-Proof создан!</p>
            <p class="proof-hash">Hash: ${proof.hash.substring(0, 20)}...</p>
            <p class="proof-claim">Подтверждено: Гражданство ${country}</p>
            <p class="proof-note">Номер паспорта НЕ раскрыт</p>
        </div>
    `;
    
    showNotification('ZK-Proof гражданства создан!', 'success');
}

function proveIncome() {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const levels = ['$0-30k', '$30k-60k', '$60k-100k', '$100k+'];
    const level = levels[Math.floor(Math.random() * levels.length)];
    
    const proof = generateZKProof('income_level', level);
    
    document.getElementById('incomeProof').innerHTML = `
        <div class="proof-success">
            <p>✅ ZK-Proof создан!</p>
            <p class="proof-hash">Hash: ${proof.hash.substring(0, 20)}...</p>
            <p class="proof-claim">Подтверждено: Доход в диапазоне ${level}</p>
            <p class="proof-note">Банковские данные НЕ раскрыты</p>
        </div>
    `;
    
    showNotification('ZK-Proof дохода создан!', 'success');
}

// ============================================
// СТЕЙКИНГ
// ============================================

function calculateStaking() {
    const amount = parseFloat(document.getElementById('stakeCalcAmount').value) || 0;
    const days = parseFloat(document.getElementById('stakeCalcDays').value) || 0;
    
    if (amount <= 0 || days <= 0) {
        showNotification('Введите корректные значения', 'error');
        return;
    }
    
    // Базовый APY + бонус за репутацию
    let apy = 5.0;
    if (appState.currentIdentity) {
        const rep = calculateTotalReputation(appState.currentIdentity);
        if (rep >= 100) apy += 2.0; // +2% за отличную репутацию
        else if (rep >= 50) apy += 1.0; // +1% за хорошую репутацию
    }
    
    const dailyRate = apy / 365 / 100;
    const rewards = amount * dailyRate * days;
    const total = amount + rewards;
    
    document.getElementById('calculatorResult').innerHTML = `
        <div class="calc-result">
            <h4>Результаты расчёта:</h4>
            <div class="calc-row">
                <span>Сумма стейкинга:</span>
                <span>${amount.toFixed(2)} токенов</span>
            </div>
            <div class="calc-row">
                <span>Период:</span>
                <span>${days} дней</span>
            </div>
            <div class="calc-row">
                <span>APY:</span>
                <span>${apy.toFixed(2)}%</span>
            </div>
            <div class="calc-row highlight">
                <span>Награды:</span>
                <span>+${rewards.toFixed(2)} токенов</span>
            </div>
            <div class="calc-row total">
                <span>Итого:</span>
                <span>${total.toFixed(2)} токенов</span>
            </div>
        </div>
    `;
}

function unstakeTokens() {
    if (!appState.currentIdentity || appState.currentIdentity.stake === 0) {
        showNotification('Нет токенов в стейкинге', 'error');
        return;
    }
    
    openModal('Вывод из стейкинга', `
        <p>Доступно для вывода: ${appState.currentIdentity.stake} токенов</p>
        <p class="text-secondary">⚠️ При выводе всех токенов вы можете потерять статус верификации</p>
        <form id="unstakeForm">
            <input type="number" id="unstakeAmount" placeholder="Количество токенов" min="1" max="${appState.currentIdentity.stake}" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet); margin: 1rem 0;">
            <button type="submit" class="btn btn-primary" style="width: 100%;">Вывести</button>
        </form>
    `);
    
    document.getElementById('unstakeForm').addEventListener('submit', (e) => {
        e.preventDefault();
        showNotification('Токены выведены из стейкинга!', 'success');
        closeModal();
    });
}

function claimRewards() {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    // Симуляция накопленных наград (0.1% от стейка в день)
    const rewards = (appState.currentIdentity.stake * 0.001 * Math.random() * 30).toFixed(2);
    
    if (parseFloat(rewards) === 0) {
        showNotification('Пока нет наград для получения', 'info');
        return;
    }
    
    showNotification(`Получено ${rewards} токенов наград!`, 'success');
    document.getElementById('stakingRewards').textContent = `${rewards} токенов`;
}

function showReceiveModal() {
    if (!appState.currentWallet) {
        showNotification('Сначала подключите кошелёк!', 'error');
        return;
    }
    
    openModal('Получить токены', `
        <div style="text-align: center;">
            <p>Ваш адрес для получения токенов:</p>
            <div style="padding: 1rem; background: var(--bg-card); border-radius: 0.5rem; margin: 1rem 0; font-family: Monaco, monospace; word-break: break-all; border: 1px solid var(--accent-violet);">
                ${appState.currentWallet}
            </div>
            <div style="margin: 2rem 0;">
                <svg viewBox="0 0 100 100" width="200" height="200" style="background: white; padding: 10px; border-radius: 0.5rem;">
                    <rect x="0" y="0" width="100" height="100" fill="white"/>
                    <rect x="10" y="10" width="15" height="15" fill="black"/>
                    <rect x="75" y="10" width="15" height="15" fill="black"/>
                    <rect x="10" y="75" width="15" height="15" fill="black"/>
                    <rect x="30" y="30" width="5" height="5" fill="black"/>
                    <rect x="40" y="30" width="5" height="5" fill="black"/>
                    <rect x="50" y="30" width="5" height="5" fill="black"/>
                    <rect x="60" y="30" width="5" height="5" fill="black"/>
                    <rect x="35" y="45" width="5" height="5" fill="black"/>
                    <rect x="55" y="45" width="5" height="5" fill="black"/>
                    <rect x="30" y="60" width="5" height="5" fill="black"/>
                    <rect x="50" y="60" width="5" height="5" fill="black"/>
                    <rect x="70" y="60" width="5" height="5" fill="black"/>
                </svg>
            </div>
            <button class="btn btn-secondary" onclick="copyAddress()" style="width: 100%;">📋 Копировать адрес</button>
        </div>
    `);
}

function copyAddress() {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(appState.currentWallet);
        showNotification('Адрес скопирован!', 'success');
    } else {
        showNotification('Копирование не поддерживается', 'error');
    }
}

// ============================================
// PILGRIMAGE (Proof-of-Pilgrimage NFTs)
// ============================================

function mintPilgrimageNFT(location, route) {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const nft = {
        id: Date.now(),
        owner: appState.currentWallet,
        location: location,
        route: route,
        timestamp: Date.now(),
        blessed: Math.random() > 0.5, // Случайно "blessed by priest"
        coordinates: {
            lat: (Math.random() * 180 - 90).toFixed(6),
            lng: (Math.random() * 360 - 180).toFixed(6)
        }
    };
    
    appState.pilgrimageNFTs.push(nft);
    storage.set('pilgrimageNFTs', appState.pilgrimageNFTs);
    
    // Добавить ачивку
    addAchievement(appState.currentWallet, `Паломник: ${location}`);
    
    showNotification(`🐚 Получен NFT: ${location}!`, 'success');
    updateUI();
}

function updatePilgrimageTab() {
    const content = document.getElementById('pilgrimageContent');
    
    if (!appState.currentIdentity) {
        content.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">🐚</div>
                <p>Создайте личность Паломника для сбора NFT-штампов маршрутов</p>
            </div>
        `;
        return;
    }
    
    const myNFTs = appState.pilgrimageNFTs.filter(nft => nft.owner === appState.currentWallet);
    const routes = [...new Set(myNFTs.map(nft => nft.route))].length;
    const totalKm = myNFTs.length * 120; // Среднее расстояние между точками
    
    const nftList = myNFTs.length > 0 ? myNFTs.map(nft => `
        <div class="nft-card">
            <div class="nft-icon">${nft.blessed ? '✝️' : '🐚'}</div>
            <div class="nft-info">
                <h4>${nft.location}</h4>
                <p class="nft-route">${nft.route}</p>
                <p class="nft-date">${new Date(nft.timestamp).toLocaleDateString()}</p>
                <p class="nft-coords">📍 ${nft.coordinates.lat}, ${nft.coordinates.lng}</p>
            </div>
        </div>
    `).join('') : '<p class="text-secondary">Пока нет NFT-штампов</p>';
    
    content.innerHTML = `
        <div class="pilgrimage-stats">
            <div class="pil-stat">
                <div class="stat-number">${myNFTs.length}</div>
                <div class="stat-label">NFT-штампов</div>
            </div>
            <div class="pil-stat">
                <div class="stat-number">${routes}</div>
                <div class="stat-label">Маршрутов</div>
            </div>
            <div class="pil-stat">
                <div class="stat-number">${totalKm}</div>
                <div class="stat-label">Километров</div>
            </div>
        </div>
        <button class="btn btn-secondary" onclick="simulatePilgrimage()" style="width: 100%; margin-bottom: 2rem;">🚶 Симулировать паломничество</button>
        <div class="nft-grid">${nftList}</div>
    `;
}

function simulatePilgrimage() {
    const locations = [
        { name: 'Jerusalem, Israel', route: 'Via Dolorosa' },
        { name: 'Santiago de Compostela, Spain', route: 'Camino de Santiago' },
        { name: 'Rome, Italy', route: 'Via Francigena' },
        { name: 'Tbilisi, Georgia', route: 'Georgian Pilgrimage' },
        { name: 'Lourdes, France', route: 'French Way' },
        { name: 'Fatima, Portugal', route: 'Portuguese Way' },
        { name: 'Mecca, Saudi Arabia', route: 'Hajj' },
        { name: 'Bethlehem, Palestine', route: 'Nativity Route' }
    ];
    
    const random = locations[Math.floor(Math.random() * locations.length)];
    mintPilgrimageNFT(random.name, random.route);
}

// ============================================
// MARKETPLACE (PilgrimHands)
// ============================================

function createTask(type, description, reward, deadline) {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const task = {
        id: Date.now(),
        type: type,
        description: description,
        reward: reward,
        deadline: deadline,
        requester: appState.currentWallet,
        status: 'open',
        applicants: [],
        createdAt: Date.now()
    };
    
    appState.marketplaceTasks.push(task);
    storage.set('marketplaceTasks', appState.marketplaceTasks);
    
    showNotification('Задача создана!', 'success');
    document.getElementById('activeTasks').textContent = appState.marketplaceTasks.filter(t => t.status === 'open').length;
    updateMarketplaceTab();
}

function applyForTask(taskId) {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const task = appState.marketplaceTasks.find(t => t.id === taskId);
    if (!task) return;
    
    if (task.applicants.includes(appState.currentWallet)) {
        showNotification('Вы уже откликнулись на эту задачу!', 'error');
        return;
    }
    
    task.applicants.push(appState.currentWallet);
    storage.set('marketplaceTasks', appState.marketplaceTasks);
    
    showNotification('Отклик отправлен!', 'success');
    updateMarketplaceTab();
}

function completeTask(taskId) {
    const task = appState.marketplaceTasks.find(t => t.id === taskId);
    if (!task) return;
    
    task.status = 'completed';
    storage.set('marketplaceTasks', appState.marketplaceTasks);
    
    // Начислить награду (симуляция escrow)
    if (appState.currentIdentity) {
        appState.currentIdentity.stake += task.reward;
        storage.set('users', appState.users);
    }
    
    showNotification(`Задача выполнена! Получено ${task.reward} токенов`, 'success');
    document.getElementById('completedTasks').textContent = parseInt(document.getElementById('completedTasks').textContent) + 1;
    updateMarketplaceTab();
}

function updateMarketplaceTab() {
    const content = document.getElementById('tasksList');
    
    const openTasks = appState.marketplaceTasks.filter(t => t.status === 'open');
    
    if (openTasks.length === 0) {
        content.innerHTML = '<p class="text-secondary" style="text-align: center; padding: 2rem;">Пока нет активных задач</p>';
        return;
    }
    
    const tasksList = openTasks.map(task => {
        const taskType = TASK_TYPES[task.type] || { name: task.type, icon: '📋' };
        const isMyTask = task.requester === appState.currentWallet;
        const hasApplied = task.applicants.includes(appState.currentWallet);
        
        return `
            <div class="task-card">
                <div class="task-header">
                    <span class="task-icon">${taskType.icon}</span>
                    <div class="task-type">${taskType.name}</div>
                    <div class="task-reward">💎 ${task.reward} токенов</div>
                </div>
                <p class="task-description">${task.description}</p>
                <div class="task-footer">
                    <span class="task-applicants">👥 ${task.applicants.length} откликов</span>
                    <span class="task-deadline">⏰ ${new Date(task.deadline).toLocaleDateString()}</span>
                </div>
                ${isMyTask ? 
                    '<button class="btn btn-secondary" onclick="completeTask(' + task.id + ')">✅ Отметить выполненной</button>' :
                    (hasApplied ? 
                        '<button class="btn btn-secondary" disabled>✓ Вы откликнулись</button>' :
                        '<button class="btn btn-primary" onclick="applyForTask(' + task.id + ')">🤲 Откликнуться</button>')
                }
            </div>
        `;
    }).join('');
    
    content.innerHTML = tasksList;
}

function showCreateTaskModal() {
    if (!appState.currentIdentity) {
        showNotification('Сначала создайте личность!', 'error');
        return;
    }
    
    const taskOptions = Object.entries(TASK_TYPES).map(([key, value]) => 
        `<option value="${key}">${value.icon} ${value.name} (${value.price} токенов)</option>`
    ).join('');
    
    openModal('Создать задачу', `
        <form id="createTaskForm">
            <div class="form-group">
                <label>Тип задачи:</label>
                <select id="taskType" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
                    ${taskOptions}
                </select>
            </div>
            <div class="form-group">
                <label>Описание:</label>
                <textarea id="taskDescription" placeholder="Подробно опишите задачу" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet); min-height: 100px;"></textarea>
            </div>
            <div class="form-group">
                <label>Награда (токенов):</label>
                <input type="number" id="taskReward" min="1" value="50" style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            </div>
            <div class="form-group">
                <label>Срок выполнения:</label>
                <input type="date" id="taskDeadline" required style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--accent-violet);">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Создать задачу</button>
        </form>
    `);
    
    // Установить минимальную дату на сегодня
    document.getElementById('taskDeadline').min = new Date().toISOString().split('T')[0];
    
    document.getElementById('createTaskForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const type = document.getElementById('taskType').value;
        const description = document.getElementById('taskDescription').value;
        const reward = parseInt(document.getElementById('taskReward').value);
        const deadline = new Date(document.getElementById('taskDeadline').value).getTime();
        
        createTask(type, description, reward, deadline);
        closeModal();
    });
}
